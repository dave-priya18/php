
<?php include('connection.php');  ?>
<?php include('include/header.php'); ?>

<div id="content">
<div id="content-wrapper">
<?php include('include/sidebar.php');  ?>

<!-- Main content area -->
<main class="container-fluid">
<div class="row">

<!-- Main content -->
<div class="col-md-8">
	


	<?php

		$FNameErr= $LNameErr = $EmailErr = $GenderErr =$UNameErr= $PwdErr = 
		$AddErr = $CNumErr = $CountryErr = $CityErr = $StateErr = $ZipErr =
		$HobbyErr = $LangErr ="";
		$hobbies =  array();
		$fname = $lname = $gender = $email = $username = $pwd = $add = $city = 
		$state = $country = $zipcode = $cno = $hobby = $language = "";
		if(isset($_POST['regButton'])){

			echo "Registration Details <br>";
			if(empty($_POST['regFName'])){
				$FNameErr = "First Name is Required";	
			}
			else{
				if(strlen($_POST['regFName']) <= 50){
					echo "First Name: ". $_POST['regFName'] . "<br>";
					$fname = $_POST['regFName'];
				}
				else{
					$FNameErr = "Length should be less than 50";
				}
				
			}
			if(empty($_POST['regLName'])){
				$LNameErr = "Last Name is Required";	
			}
			else{
				if(strlen($_POST['regLName']) <= 50){
					echo "Last Name: ".$_POST['regLName'] ."<br>";
					$lname = $_POST['regLName'];
				}
				else{
					$LNameErr = "Length should be less than 50";
				}
				
			}
			if(empty($_POST['regGender'])){
				$GenderErr = "must select one";
			}
			else{
				echo "Gender: ".$_POST['regGender']."<br>";
				$gender = $_POST['regGender'];
			}

			  
			if(empty($_POST['regEmail'])){
				$EmailErr = "Email is Required";	
			}
			else{
				// if (filter_var($_POST['regEmail'], FILTER_VALIDATE_EMAIL)) {
				// 	echo "Email Id(function): ".$_POST['regEmail']."<br>";
				// }
				// else{
				// 	$EmailErr = "Wrong Email Format";
				// }
				if (preg_match("/^([-a-zA-Z0-9_.]+)@([-a-zA-Z0-9_.]+)\.([a-zA-Z])*$/",$_POST['regEmail'])) {
					echo "Email Id(regex): ".$_POST['regEmail']."<br>";
					$email = $_POST['regEmail'];
				}
				else{
					$EmailErr = "Wrong Email Format";
				}
				
			}
			if(empty($_POST['regUName'])){
				$UNameErr = "Username is Required";	
			}
			else{
				if (strlen($_POST['regUName']) >5 && strlen($_POST['regUName']) < 11) {
					if(preg_match("/^[_A-Za-z0-9]*$/", $_POST['regUName'])){
						echo "UserName: ".$_POST['regUName']."<br>";
						$username = $_POST['regUName'];
					}
					else{
						$UNameErr = "Format Problem";
					}		
				}
				else{

					$UNameErr = "Length problem";
				}				
			}

			if(empty($_POST['regPwd'])){
				$PwdErr = "Password is Required";	
			}
			else{
			 	if (strlen($_POST['regPwd']) >5 && strlen($_POST['regPwd']) < 16) {
					// if(preg_match("/^[-_a-zA-Z0-9@*#!$%^&*+=,.:;?]*$/", $_POST['regPwd'])){
					// 	echo "Password: ".$_POST['regPwd']."<br>";
					// }
					$lcount = $ucount = $ncount = $pcount = 0;
					$pwd = $_POST['regPwd'];
					for($i=0;$i<strlen($pwd);$i++){
						if(ctype_lower($pwd[$i])){
							$lcount++;
						}
						elseif(ctype_upper($pwd[$i])){
							$ucount++;
						}
						elseif(ctype_digit($pwd[$i])){
							$ncount++;
						}
						elseif(ctype_punct($pwd[$i])){
							$pcount++;
						}	
					}
					if($lcount >0 && $ucount > 0 && $ncount>0 && $pcount >0){
						echo "Password: ".$_POST['regPwd']."<br>";
						//echo $lcount.$ucount.$ncount.$pcount;
					}
					else{
						echo "Atleast One Upper Case, Lower Case, Number and Special Character is must";
					}
				}	
			}

			if(($_POST['regAdd']== "")){
				$AddErr = "Address is Required";	
			}
			else{
				if (strlen($_POST['regAdd']) < 201 ) {
					echo "Address: ".$_POST['regAdd']."<br>";
					$add = $_POST['regAdd'];
				}
				else{

					$AddErr = "Length problem";
				}				
			}

			if(empty($_POST['regCNumber'])){
				$CNumErr = "Contact Number  is Required";	
			}
			else{
				if (strlen($_POST['regCNumber']) == 10 ) {
					if(preg_match("/^[6789][0-9]*$/", $_POST['regCNumber'])){
						echo "Contact Number: ".$_POST['regCNumber']."<br>";
						 $cno = $_POST['regCNumber'];
						//exit;
					}
					else{
						echo "Format probelm";
					}
					
				}
				else{

					$CNumErr = "Length problem";
				}				
			}

			if(empty($_POST['regCity'])){
				$CityErr = "City is Required";	
			}
			else{
				if(strlen($_POST['regCity']) < 101 ){
				   echo "City: ".$_POST['regCity']."<br>";
					$city = $_POST['regCity'];
				}
				else
					$CityErr = "Too Long City Name";
			}

			if(empty($_POST['regState'])){
				$StateErr = "State is Required";	
			}
			else{
				if(strlen($_POST['regState']) < 101){
				   echo "State: ".$_POST['regState']."<br>";
					$state = $_POST['regState'];
				}
				else
					$StateErr = "Too Long State Name";
			}


			if(empty($_POST['regCountry'])){
				$CountryErr = "Country is Required";	
			}
			else{
				   echo "Country: ".$_POST['regCountry']."<br>";
				   $country = $_POST['regCountry'];
			}

			if(empty($_POST['regZipCode'])){
				$ZipErr = "Zip code is Required";	
			}
			else{
				if (strlen($_POST['regZipCode']) == 6 ) {
					if(preg_match("/^([0-9]*),[0-9]*$/", $_POST['regZipCode'])){
						echo "Zip-Code: ".$_POST['regZipCode']."<br>";
						$zipcode = $_POST['regZipCode'];
					}
					else{
						echo "Format probelm";
					}
					
				}
				else{

					$ZipErr = "Length problem";
				}				
			}
			echo "Hobbies: ";
			if(isset($_POST['regCheckbox'])){
				if(count($_POST['regCheckbox']) >= 3){
		    		foreach ($_POST['regCheckbox'] as $checked) {
		      			echo $checked." ";
		      			$hobby .= $checked;
		    		}
		  		}
		  	}
		  	else{
		  		$HobbyErr = "Must provide 3 Hobbies";
		  	}
		  	echo "<br>"."Language Known: ";

		  	if(empty($_POST['regLanguage'])){
		  		$LangErr = "Language Required";
		  	}
		  	else{
		  		foreach ($_POST['regLanguage'] as $checked) {
		    	echo $checked." ";
		    	$language .= $checked;
		  }
		  	}
		  	echo "<br>";




		 //DB Connection and Insert
				$_connection = create_connection();
				echo "Connection Successful <br>";
				$insert_query = "insert into User_Info(first_name,last_name,gender,email_id,username,password,address,city,state,country,zip_code,
			contact_number,hobby,language_known) values ('".$fname."','".$lname."','".$gender."','".$email."','".$username."','".$pwd."','".$add."','".$city."','".$state."','".$country."','".$zipcode."','".$cno."','".$hobby."','".$language."')";
				echo $insert_query;
				if (mysqli_query($_connection,$insert_query)) {
    				echo "New record created successfully <br>";
				} else {
    				echo mysqli_error($_connection,$insert_query);
				}
				close_connection($_connection);




		}


	?>

	<form method="POST" >
	<a href="Priya-01-22.php"> Next </a>
	<h2 class="contentTitle"> Registration Details </h2>
	<br> <br>

	First Name:
	<input type="text" maxlength="50" name="regFName" id="regTxt1">
	<span class="error">* <?php echo $FNameErr;?></span> <br> <br>
	Last Name:
	<input type="text"  maxlength="50" name="regLName" id="regTxt2">
	<span class="error">* <?php echo $LNameErr;?></span> <br> <br>
	Gender:
	<input type="radio"  name="regGender" value="F" id="regRadio1"> F
	<input type="radio"  name="regGender" value="M" id="regRadio2"> M
	<span class="error">* <?php echo $GenderErr;?></span><br> <br>
	Email-Id:
	<input type="text"  name="regEmail" id="regTxt3"> 
	<span class="error">* <?php echo $EmailErr;?></span><br> <br>
	Username:
	<input type="text"  minlength="6" maxlength="10" name="regUName" id="regTxt4">
	<span class="error">* <?php echo $UNameErr;?></span> <br> <br>
	Password:
	<input type="password" minlength="6" maxlength="16" name="regPwd" id="regPwd1"> 
	<span class="error">* <?php echo $PwdErr;?></span> <br> <br>
	Address:
	<textarea  name="regAdd" id="regTxtarea1" rows="5" maxlength="200" cols="40">  </textarea> 
	<span class="error">* <?php echo $AddErr;?></span><br> <br>
	City:
	<input type="text" name="regCity" maxlength="100"> 
	<span class="error">* <?php echo $CityErr;?></span>
	State:
	<input type="text" name="regState" maxlength="100"> 
	<span class="error">* <?php echo $StateErr;?></span> <br> <br>
	Country:
		<select  name="regCountry" id="regDropDown1">
			<option  value="India" id="regCountry1"> India </option>
			<option  value="Sri-Lanka" id="regCountry1"> Sri-Lanka </option>
			<option  value="Bhutan" id="regCountry1"> Bhutan </option>
			<option  value="Pakistan" id="regCountry1">Pakistan </option>
			<option  value="China" id="regCountry1">China </option>
		</select> 
		<span class="error">* <?php echo $CountryErr;?></span><br> <br>
	Zip Code:
	<input type="text" name="regZipCode"> 
	<span class="error">* <?php echo $ZipErr;?></span> <br> <br>
	Contact Number:
	<input type="text" name="regCNumber"> 
	<span class="error">* <?php echo $CNumErr;?></span><br> <br>
	Hobbies:
	<input type="checkbox"  name="regCheckbox[]" value="Reading" id="regCheckbox1"> Reading
	<input type="checkbox" name="regCheckbox[]" value="Watching TV Series/Movies" id="regCheckbox2">Watching TV Series/Movies
	<input type="checkbox"  name="regCheckbox[]" value="Listening Songs" id="regCheckbox3"> Listening Songs
	<input type="checkbox"  name="regCheckbox[]" value="Cooking" id="regCheckbox4">Cooking
	<input type="checkbox"  name="regCheckbox[]" value="Traveling" id="regCheckbox5"> Traveling
	<input type="checkbox"  name="regCheckbox[]" value="Dancing" id="regCheckbox6"> Dancing 
	<span class="error">* <?php echo $HobbyErr;?></span><br> <br>
		
	Language Known:
	<select  name="regLanguage[]" id="regDropDown1" multiple>
		<option  value="Gujarati" id="regLanguage1"> Gujarati </option>
		<option  value="English" id="regLanguage2"> English </option>
		<option  value="Hindi" id="regLanguage3"> Hindi </option>
	</select> 
	<span class="error">* <?php echo $LangErr;?></span><br> <br>

	<input type="submit"  name="regButton" value="Register" id="regbtn1">


	</form>







<?php include('include/rightSidebar.php'); ?>

<?php include('include/footer.php'); ?>
		
