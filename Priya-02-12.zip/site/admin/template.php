<?php
?>

<?php include('layout/header.php'); ?>
<?php include('layout/leftsidebar.php'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">

                </div>
            </div>
        </div>


<?php include('layout/footer.php'); ?>
