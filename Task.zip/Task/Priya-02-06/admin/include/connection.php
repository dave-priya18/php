<?php
require('session.php');

 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "portfolio_admin";
 
 
 $_connection = mysqli_connect($dbhost,$dbuser,$dbpass,$db) or die("Can't Connect");



?>