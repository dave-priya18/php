<?php
?>

<?php include('layout/header.php'); ?>
<?php include('layout/leftsidebar.php'); ?>
        




        <div id="map"></div>
         <script>
        $().ready(function(){
            demo.initGoogleMaps();
        });
    </script>

   <?php include('layout/footer.php'); ?>
