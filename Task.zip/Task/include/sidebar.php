
                <!-- Jumbtron / Slider -->
                <div class="jumbotron-wrap">
                    <div class="container-fluid">
                        <div id="mainCarousel" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="jumbotron">
                                        <h1 class="text-center">Tristique sem vitae metus ornare </h1>
                                        <p class="lead text-center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
                                        <p class="lead text-center">
                                                <a class="btn btn-primary btn-lg" href="#" role="button"><i class="fa fa-info"></i> &nbsp; Learn more</a>
                                            <a class="btn btn-secondary btn-lg" href="#" role="button"><i class="fa fa-gbp"></i> &nbsp; Buy now</a>
                                        </p>
                                    </div>

                                </div>

                                <div class="carousel-item">
                                    <div class="jumbotron">
                                        <h1 class="text-center">Cras sit amet nibh libero, in gravida nulla</h1>
                                        <p class="lead text-center">Nulla vel metus scelerisque ante sollicitudin. Cras purus odio.</p>
                                        <p class="lead text-center">
                                                <a class="btn btn-outline-primary btn-lg" href="#" role="button"><i class="fa fa-info"></i> &nbsp; Learn more</a>
                                            <a class="btn btn-outline-secondary btn-lg" href="#" role="button"><i class="fa fa-gbp"></i> &nbsp; Buy now</a>
                                        </p>
                                    </div>

                                </div>
                            </div>

                            <a class="carousel-control-prev" href="#mainCarousel" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#mainCarousel" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
